/* ============================================================
   seed_questions.c — Run this ONCE to populate questions.dat
   Compile separately:
     gcc -o seed seed_questions.c
     ./seed
   ============================================================ */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_QUESTION_LEN 256
#define MAX_OPTION_LEN   100
#define QUESTIONS_FILE   "data/questions.dat"

#define EASY   0
#define NORMAL 1
#define HARD   2

typedef struct {
    char question[MAX_QUESTION_LEN];
    char options[4][MAX_OPTION_LEN];
    int  correct;
    int  difficulty;
} Question;

/* Helper to fill and write a question */
static void add_q(FILE *fp,
                  const char *q,
                  const char *a, const char *b,
                  const char *c, const char *d,
                  int correct, int diff)
{
    Question qu;
    memset(&qu, 0, sizeof(qu));
    strncpy(qu.question,    q, MAX_QUESTION_LEN - 1);
    strncpy(qu.options[0],  a, MAX_OPTION_LEN - 1);
    strncpy(qu.options[1],  b, MAX_OPTION_LEN - 1);
    strncpy(qu.options[2],  c, MAX_OPTION_LEN - 1);
    strncpy(qu.options[3],  d, MAX_OPTION_LEN - 1);
    qu.correct    = correct;
    qu.difficulty = diff;
    fwrite(&qu, sizeof(Question), 1, fp);
}

int main(void) {
    system("mkdir -p data 2>/dev/null || mkdir data 2>nul");

    FILE *fp = fopen(QUESTIONS_FILE, "wb");
    if (!fp) {
        fprintf(stderr, "Cannot create %s\n", QUESTIONS_FILE);
        return 1;
    }

    /* ════════════════════════════════════════
       EASY QUESTIONS (difficulty = 0)
       ════════════════════════════════════════ */
    add_q(fp, "What is the capital of France?",
          "Berlin", "Madrid", "Paris", "Rome", 2, EASY);

    add_q(fp, "Which planet is known as the Red Planet?",
          "Venus", "Mars", "Jupiter", "Saturn", 1, EASY);

    add_q(fp, "How many sides does a triangle have?",
          "2", "3", "4", "5", 1, EASY);

    add_q(fp, "What is 7 x 8?",
          "54", "56", "58", "64", 1, EASY);

    add_q(fp, "Which animal is known as the 'King of the Jungle'?",
          "Tiger", "Elephant", "Lion", "Cheetah", 2, EASY);

    add_q(fp, "What color is the sky on a clear day?",
          "Green", "Red", "Blue", "Yellow", 2, EASY);

    add_q(fp, "How many months are in a year?",
          "10", "11", "12", "13", 2, EASY);

    add_q(fp, "What is the largest ocean on Earth?",
          "Atlantic", "Indian", "Arctic", "Pacific", 3, EASY);

    add_q(fp, "In which country was the Eiffel Tower built?",
          "Italy", "Germany", "France", "Spain", 2, EASY);

    add_q(fp, "What is H2O commonly known as?",
          "Salt", "Water", "Oxygen", "Hydrogen", 1, EASY);

    add_q(fp, "Which shape has four equal sides?",
          "Rectangle", "Triangle", "Square", "Pentagon", 2, EASY);

    add_q(fp, "What is the smallest prime number?",
          "0", "1", "2", "3", 2, EASY);

    add_q(fp, "How many days are in a week?",
          "5", "6", "7", "8", 2, EASY);

    add_q(fp, "Which fruit is known as the 'king of fruits'?",
          "Mango", "Banana", "Apple", "Grape", 0, EASY);

    add_q(fp, "What language does Brazil speak?",
          "Spanish", "English", "French", "Portuguese", 3, EASY);

    /* ════════════════════════════════════════
       NORMAL QUESTIONS (difficulty = 1)
       ════════════════════════════════════════ */
    add_q(fp, "Who wrote 'Romeo and Juliet'?",
          "Charles Dickens", "William Shakespeare", "Mark Twain", "Homer", 1, NORMAL);

    add_q(fp, "What is the chemical symbol for Gold?",
          "Go", "Gd", "Au", "Ag", 2, NORMAL);

    add_q(fp, "Which organ pumps blood through the human body?",
          "Lungs", "Liver", "Brain", "Heart", 3, NORMAL);

    add_q(fp, "In what year did World War II end?",
          "1943", "1944", "1945", "1946", 2, NORMAL);

    add_q(fp, "What is the speed of light (approx) in km/s?",
          "150,000", "200,000", "300,000", "400,000", 2, NORMAL);

    add_q(fp, "Who painted the Mona Lisa?",
          "Van Gogh", "Picasso", "Michelangelo", "Leonardo da Vinci", 3, NORMAL);

    add_q(fp, "What is the longest river in the world?",
          "Amazon", "Nile", "Yangtze", "Mississippi", 1, NORMAL);

    add_q(fp, "What is the hardest natural substance on Earth?",
          "Gold", "Iron", "Diamond", "Quartz", 2, NORMAL);

    add_q(fp, "Which gas do plants absorb from the atmosphere?",
          "Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen", 2, NORMAL);

    add_q(fp, "How many bones are in the adult human body?",
          "196", "206", "216", "226", 1, NORMAL);

    add_q(fp, "Which planet has the most moons?",
          "Jupiter", "Saturn", "Uranus", "Neptune", 1, NORMAL);

    add_q(fp, "What is the powerhouse of the cell?",
          "Nucleus", "Ribosome", "Mitochondria", "Golgi Body", 2, NORMAL);

    add_q(fp, "Who invented the telephone?",
          "Edison", "Tesla", "Bell", "Marconi", 2, NORMAL);

    add_q(fp, "What does CPU stand for?",
          "Central Process Unit", "Central Processing Unit",
          "Computer Processing Unit", "Core Processing Unit", 1, NORMAL);

    add_q(fp, "Which continent is the Sahara Desert located on?",
          "Asia", "Australia", "South America", "Africa", 3, NORMAL);

    /* ════════════════════════════════════════
       HARD QUESTIONS (difficulty = 2)
       ════════════════════════════════════════ */
    add_q(fp, "What is the derivative of sin(x)?",
          "-cos(x)", "cos(x)", "-sin(x)", "tan(x)", 1, HARD);

    add_q(fp, "In which year was the C programming language created?",
          "1968", "1969", "1972", "1978", 2, HARD);

    add_q(fp, "What is the atomic number of Carbon?",
          "4", "6", "8", "12", 1, HARD);

    add_q(fp, "What does DNA stand for?",
          "Deoxyribonucleic Acid", "Diribonucleic Acid",
          "Deoxyribose Nucleic Acid", "Double Nucleic Acid", 0, HARD);

    add_q(fp, "Which sorting algorithm has the best average time complexity?",
          "Bubble Sort", "Insertion Sort", "Quick Sort", "Selection Sort", 2, HARD);

    add_q(fp, "What is Avogadro's number (approx)?",
          "3.14 x 10^23", "6.02 x 10^23", "9.81 x 10^23", "1.67 x 10^23", 1, HARD);

    add_q(fp, "Which theorem states: a^2 + b^2 = c^2?",
          "Fermat's Last Theorem", "Pythagorean Theorem",
          "Euclidean Theorem", "Newton's Theorem", 1, HARD);

    add_q(fp, "What is the time complexity of binary search?",
          "O(n)", "O(n^2)", "O(log n)", "O(n log n)", 2, HARD);

    add_q(fp, "Who proposed the theory of General Relativity?",
          "Newton", "Bohr", "Einstein", "Hawking", 2, HARD);

    add_q(fp, "What does RAM stand for?",
          "Read Access Memory", "Random Access Memory",
          "Rapid Access Memory", "Read-only Access Memory", 1, HARD);

    add_q(fp, "In C, what is sizeof(int) on a typical 64-bit system?",
          "2", "4", "8", "16", 1, HARD);

    add_q(fp, "What is the capital of Kazakhstan?",
          "Almaty", "Nur-Sultan (Astana)", "Bishkek", "Tashkent", 1, HARD);

    add_q(fp, "Which data structure uses LIFO order?",
          "Queue", "Stack", "Heap", "Tree", 1, HARD);

    add_q(fp, "What is the value of Euler's number 'e' (approx)?",
          "2.718", "3.141", "1.618", "1.414", 0, HARD);

    add_q(fp, "In which year was the first computer virus created?",
          "1971", "1981", "1986", "1991", 0, HARD);

    fclose(fp);
    printf("✔ Seeded %s with questions for Easy, Normal, and Hard.\n", QUESTIONS_FILE);
    printf("  You can now run ./quiz and play!\n");
    return 0;
}
