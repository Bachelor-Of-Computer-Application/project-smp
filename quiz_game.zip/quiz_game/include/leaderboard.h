#ifndef LEADERBOARD_H
#define LEADERBOARD_H

#include "utils.h"
#include "player.h"

/* ── Score Entry Structure ── */
typedef struct {
    char name[MAX_NAME_LEN];  /* Player name              */
    int  score;               /* Final score              */
    int  difficulty;          /* Difficulty played        */
    int  correct;             /* Correct answers          */
    int  total;               /* Total questions answered */
    char date[20];            /* Date string              */
} ScoreEntry;

/* ── File Path ── */
#define SCORES_FILE "data/scores.dat"

/* ── Function Prototypes ── */
void save_score(Player *p);
void load_scores(ScoreEntry *entries, int *count);
void sort_scores(ScoreEntry *entries, int count);
void display_leaderboard(void);
void display_leaderboard_filtered(int difficulty);

#endif /* LEADERBOARD_H */
