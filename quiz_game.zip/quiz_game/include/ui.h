#ifndef UI_H
#define UI_H

#include "utils.h"

/* ── Function Prototypes ── */
void display_main_banner(void);
void display_main_menu(void);
void display_difficulty_menu(void);
void display_game_over_banner(int score, int correct, int total);
void display_correct_answer(void);
void display_wrong_answer(const char *correct_opt);
void display_timeout_message(void);
void display_admin_banner(void);
void display_leaderboard_header(void);
void display_progress_bar(int current, int total);
void display_loading(const char *msg);
void display_goodbye(void);
void display_score_badge(int score, int difficulty);
void animated_dots(const char *msg, int count);

#endif /* UI_H */
