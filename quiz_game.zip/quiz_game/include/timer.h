#ifndef TIMER_H
#define TIMER_H

#include "utils.h"

/* ── Timer Structure ── */
typedef struct {
    time_t start;     /* When the timer started      */
    int    limit;     /* Time limit in seconds       */
} Timer;

/* ── Function Prototypes ── */
void  timer_start(Timer *t, int seconds);
int   timer_elapsed(Timer *t);
int   timer_remaining(Timer *t);
int   timer_expired(Timer *t);
void  display_timer_bar(int remaining, int total);

#endif /* TIMER_H */
