#ifndef QUIZ_H
#define QUIZ_H

#include "utils.h"
#include "player.h"

/* ── Question Structure ── */
typedef struct {
    char question[MAX_QUESTION_LEN];  /* The question text            */
    char options[4][MAX_OPTION_LEN];  /* Four answer choices           */
    int  correct;                     /* Correct answer index (0–3)   */
    int  difficulty;                  /* EASY=0, NORMAL=1, HARD=2     */
} Question;

/* ── Quiz Session ── */
typedef struct {
    Question questions[MAX_QUESTIONS]; /* Loaded question pool         */
    int      count;                    /* Number of questions loaded   */
    int      order[MAX_QUESTIONS];     /* Shuffled index array         */
    int      q_per_game;              /* Questions shown per game     */
    int      time_limit;              /* Seconds allowed per question */
} QuizSession;

/* ── Scoring Constants ── */
#define BASE_SCORE_EASY    10
#define BASE_SCORE_NORMAL  20
#define BASE_SCORE_HARD    30
#define BONUS_EASY          5
#define BONUS_NORMAL       10
#define BONUS_HARD         15
#define BONUS_TIME_EASY    10   /* seconds to qualify for bonus */
#define BONUS_TIME_NORMAL  15
#define BONUS_TIME_HARD    20

/* ── Function Prototypes ── */
int  load_questions(QuizSession *session, int difficulty);
void shuffle_questions(QuizSession *session);
void run_quiz(Player *player);
void display_question(QuizSession *session, int index, int q_num, int total);
int  check_answer(QuizSession *session, int index, int answer);
int  calculate_score(int difficulty, int time_taken);
void show_result_screen(Player *player);
void configure_session(QuizSession *session, int difficulty);

#endif /* QUIZ_H */
