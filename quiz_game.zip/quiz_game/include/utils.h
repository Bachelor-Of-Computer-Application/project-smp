#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

/* ── Cross-platform clear screen ── */
#ifdef _WIN32
  #define CLEAR "cls"
#else
  #define CLEAR "clear"
#endif

/* ── ANSI Color Codes ── */
#define COLOR_RESET   "\033[0m"
#define COLOR_RED     "\033[1;31m"
#define COLOR_GREEN   "\033[1;32m"
#define COLOR_YELLOW  "\033[1;33m"
#define COLOR_BLUE    "\033[1;34m"
#define COLOR_MAGENTA "\033[1;35m"
#define COLOR_CYAN    "\033[1;36m"
#define COLOR_WHITE   "\033[1;37m"
#define COLOR_BOLD    "\033[1m"
#define BG_BLUE       "\033[44m"
#define BG_GREEN      "\033[42m"
#define BG_RED        "\033[41m"

/* ── Constants ── */
#define MAX_QUESTIONS     200
#define MAX_NAME_LEN       50
#define MAX_QUESTION_LEN  256
#define MAX_OPTION_LEN    100
#define MAX_SCORES         50
#define ADMIN_PASSWORD    "admin123"

/* ── Difficulty Levels ── */
#define EASY   0
#define NORMAL 1
#define HARD   2

/* ── Utility Function Prototypes ── */
void  clear_screen(void);
void  flush_input(void);
int   get_int_input(int min, int max);
void  get_string_input(char *buffer, int size);
void  seed_random(void);
int   random_range(int min, int max);
void  to_lowercase(char *str);
void  sleep_ms(int ms);
void  pause_enter(void);
void  get_current_date(char *buffer, int size);
void  print_separator(char ch, int width);

#endif /* UTILS_H */
