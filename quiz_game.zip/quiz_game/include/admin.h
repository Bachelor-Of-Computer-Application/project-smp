#ifndef ADMIN_H
#define ADMIN_H

#include "utils.h"
#include "quiz.h"

/* ── File Path ── */
#define QUESTIONS_FILE "data/questions.dat"

/* ── Function Prototypes ── */
int  admin_login(void);
void admin_menu(void);
void admin_add_question(void);
void admin_view_questions(void);
void admin_delete_question(void);
void admin_view_by_difficulty(int difficulty);
int  save_question(Question *q);
int  get_total_questions(void);

#endif /* ADMIN_H */
