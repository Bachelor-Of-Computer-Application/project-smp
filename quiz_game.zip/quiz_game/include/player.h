#ifndef PLAYER_H
#define PLAYER_H

#include "utils.h"

/* ── Player Session Structure ── */
typedef struct {
    char name[MAX_NAME_LEN];     /* Player's display name            */
    int  score;                  /* Accumulated score this session   */
    int  difficulty;             /* Chosen difficulty level          */
    int  questions_answered;     /* Total questions seen             */
    int  correct_answers;        /* Number of correct answers        */
    int  total_time;             /* Total seconds used               */
} Player;

/* ── Function Prototypes ── */
void init_player(Player *p);
void get_player_name(Player *p);
int  select_difficulty(Player *p);
void display_player_stats(Player *p);
void reset_player(Player *p);

#endif /* PLAYER_H */
