/* ============================================================
   utils.c — Utility helpers: input, RNG, formatting, timing
   ============================================================ */

/* Enable POSIX extensions for nanosleep / struct timespec */
#define _POSIX_C_SOURCE 199309L

#include "utils.h"
#include <time.h>

/* ── Clear the terminal screen ── */
void clear_screen(void) {
    system(CLEAR);
}

/* ── Discard leftover characters in stdin buffer ── */
void flush_input(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

/* ── Read a validated integer in [min, max] ── */
int get_int_input(int min, int max) {
    int value;
    char buf[32];
    while (1) {
        if (fgets(buf, sizeof(buf), stdin) == NULL) continue;
        /* Remove trailing newline */
        buf[strcspn(buf, "\n")] = '\0';
        /* Check all characters are digits (allow leading minus) */
        int valid = 1;
        int start = (buf[0] == '-') ? 1 : 0;
        if (buf[start] == '\0') valid = 0;
        for (int i = start; buf[i] != '\0'; i++) {
            if (!isdigit((unsigned char)buf[i])) { valid = 0; break; }
        }
        if (valid) {
            value = atoi(buf);
            if (value >= min && value <= max) return value;
        }
        printf(COLOR_RED "  ✗ Invalid input. Enter a number between %d and %d: " COLOR_RESET, min, max);
    }
}

/* ── Read a string safely, strip newline ── */
void get_string_input(char *buffer, int size) {
    if (fgets(buffer, size, stdin) == NULL) {
        buffer[0] = '\0';
        return;
    }
    buffer[strcspn(buffer, "\n")] = '\0';
    /* Trim leading spaces */
    int i = 0;
    while (buffer[i] == ' ') i++;
    if (i > 0) memmove(buffer, buffer + i, strlen(buffer) - i + 1);
}

/* ── Seed the random number generator once ── */
void seed_random(void) {
    srand((unsigned int)time(NULL));
}

/* ── Return a random integer in [min, max] (inclusive) ── */
int random_range(int min, int max) {
    if (max <= min) return min;
    return min + rand() % (max - min + 1);
}

/* ── Convert a string to lowercase in-place ── */
void to_lowercase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = (char)tolower((unsigned char)str[i]);
    }
}

/* ── Platform-safe millisecond sleep ── */
void sleep_ms(int ms) {
#ifdef _WIN32
    /* Windows: use Sleep() from windows.h */
    /* We avoid including windows.h globally; use a busy loop instead */
    clock_t start = clock();
    while ((clock() - start) * 1000 / CLOCKS_PER_SEC < ms);
#else
    struct timespec ts;
    ts.tv_sec  = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
#endif
}

/* ── Wait for the user to press Enter ── */
void pause_enter(void) {
    printf(COLOR_CYAN "\n  Press ENTER to continue..." COLOR_RESET);
    flush_input();
}

/* ── Get today's date as "YYYY-MM-DD" ── */
void get_current_date(char *buffer, int size) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    strftime(buffer, size, "%Y-%m-%d", t);
}

/* ── Print a horizontal separator line ── */
void print_separator(char ch, int width) {
    for (int i = 0; i < width; i++) putchar(ch);
    putchar('\n');
}
