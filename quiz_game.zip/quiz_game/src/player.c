/* ============================================================
   player.c — Player session initialization and management
   ============================================================ */

#include "player.h"
#include "ui.h"
#include <stdio.h>
#include <string.h>

/* ── Zero-initialize all fields in a Player struct ── */
void init_player(Player *p) {
    memset(p->name, 0, sizeof(p->name));
    p->score               = 0;
    p->difficulty          = EASY;
    p->questions_answered  = 0;
    p->correct_answers     = 0;
    p->total_time          = 0;
}

/* ── Prompt the user to enter their display name ── */
void get_player_name(Player *p) {
    printf(COLOR_CYAN "\n  ┌────────────────────────────────────┐\n" COLOR_RESET);
    printf(COLOR_CYAN "  │" COLOR_BOLD "     Enter Your Name to Begin         " COLOR_RESET COLOR_CYAN "│\n" COLOR_RESET);
    printf(COLOR_CYAN "  └────────────────────────────────────┘\n" COLOR_RESET);
    printf(COLOR_BOLD "  Name: " COLOR_RESET);

    get_string_input(p->name, MAX_NAME_LEN);

    /* Default name if nothing entered */
    if (strlen(p->name) == 0) {
        strncpy(p->name, "Player", MAX_NAME_LEN - 1);
    }

    printf(COLOR_GREEN "\n  Welcome, %s! Let's choose your difficulty.\n" COLOR_RESET, p->name);
    sleep_ms(500);
}

/* ── Let the player choose a difficulty level ── */
int select_difficulty(Player *p) {
    display_difficulty_menu();

    int choice = get_int_input(1, 3);
    switch (choice) {
        case 1: p->difficulty = EASY;   break;
        case 2: p->difficulty = NORMAL; break;
        case 3: p->difficulty = HARD;   break;
        default: p->difficulty = EASY;  break;
    }

    const char *labels[] = { "EASY 🟢", "NORMAL 🟡", "HARD 🔴" };
    printf(COLOR_GREEN "\n  Difficulty set to: " COLOR_BOLD "%s\n" COLOR_RESET,
           labels[p->difficulty]);
    sleep_ms(600);
    return p->difficulty;
}

/* ── Print a per-game summary of the player's performance ── */
void display_player_stats(Player *p) {
    float accuracy = (p->questions_answered > 0)
                   ? (float)p->correct_answers / p->questions_answered * 100.0f
                   : 0.0f;

    printf("\n");
    printf(COLOR_WHITE "  ┌─────────────────────────────────────┐\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_BOLD "         YOUR STATS                    " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  ├─────────────────────────────────────┤\n" COLOR_RESET);
    printf(COLOR_WHITE "  │  Player   : " COLOR_CYAN "%-24s" COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET, p->name);
    printf(COLOR_WHITE "  │  Score    : " COLOR_YELLOW "%-24d" COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET, p->score);
    printf(COLOR_WHITE "  │  Correct  : " COLOR_GREEN "%-2d" COLOR_WHITE " / %-2d                    │\n" COLOR_RESET,
           p->correct_answers, p->questions_answered);
    printf(COLOR_WHITE "  │  Accuracy : " COLOR_CYAN "%-5.1f%%                   " COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET, accuracy);
    printf(COLOR_WHITE "  └─────────────────────────────────────┘\n" COLOR_RESET);
}

/* ── Reset score/answer counters for a replay, keep the name ── */
void reset_player(Player *p) {
    p->score              = 0;
    p->questions_answered = 0;
    p->correct_answers    = 0;
    p->total_time         = 0;
}
