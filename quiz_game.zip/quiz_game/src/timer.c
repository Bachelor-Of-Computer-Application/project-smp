/* ============================================================
   timer.c — Question countdown timer
   ============================================================ */

#include "timer.h"
#include <stdio.h>

/* ── Start the timer with a given second limit ── */
void timer_start(Timer *t, int seconds) {
    t->start = time(NULL);
    t->limit = seconds;
}

/* ── Return how many seconds have elapsed ── */
int timer_elapsed(Timer *t) {
    return (int)(time(NULL) - t->start);
}

/* ── Return how many seconds remain ── */
int timer_remaining(Timer *t) {
    int rem = t->limit - timer_elapsed(t);
    return (rem < 0) ? 0 : rem;
}

/* ── Return 1 if the time limit has been exceeded ── */
int timer_expired(Timer *t) {
    return timer_elapsed(t) >= t->limit;
}

/* ── Draw a visual countdown bar ── */
void display_timer_bar(int remaining, int total) {
    int bar_width = 20;
    int filled    = (total > 0) ? (remaining * bar_width / total) : 0;

    /* Color based on urgency */
    const char *bar_color;
    if      (remaining > total / 2) bar_color = COLOR_GREEN;
    else if (remaining > total / 4) bar_color = COLOR_YELLOW;
    else                            bar_color = COLOR_RED;

    printf("  ⏱  Timer [");
    printf("%s", bar_color);
    for (int i = 0; i < filled; i++)           printf("\xe2\x96\x88");   /* █ */
    printf(COLOR_RESET);
    for (int i = filled; i < bar_width; i++)   printf("\xe2\x96\x91"); /* ░ */
    printf("] ");
    printf("%s%2ds%s\n", bar_color, remaining, COLOR_RESET);
}
