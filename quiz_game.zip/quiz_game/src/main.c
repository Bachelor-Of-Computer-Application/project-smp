/* ============================================================
   main.c — Entry point for the Terminal Quiz Game
   Initializes systems, shows main menu, routes to features.
   ============================================================ */

#include "utils.h"
#include "ui.h"
#include "player.h"
#include "quiz.h"
#include "leaderboard.h"
#include "admin.h"

int main(void) {
    /* ── Seed random number generator once at startup ── */
    seed_random();

    /* ── Ensure data directory exists ── */
    system("mkdir -p data 2>/dev/null || mkdir data 2>nul");

    int choice;
    int running = 1;

    while (running) {
        display_main_banner();
        display_main_menu();

        choice = get_int_input(1, 5);

        switch (choice) {

            /* ── Play Quiz ── */
            case 1: {
                Player player;
                int    replay = 1;

                get_player_name(&player);

                while (replay) {
                    init_player(&player);       /* Reset score each game   */
                    select_difficulty(&player);
                    run_quiz(&player);

                    /* Replay prompt */
                    printf(COLOR_CYAN "\n  ┌──────────────────────────────┐\n" COLOR_RESET);
                    printf(COLOR_CYAN "  │" COLOR_BOLD "  Play again?                 " COLOR_RESET COLOR_CYAN "│\n" COLOR_RESET);
                    printf(COLOR_CYAN "  │" COLOR_GREEN "  [1] Yes, replay!            " COLOR_RESET COLOR_CYAN "│\n" COLOR_RESET);
                    printf(COLOR_CYAN "  │" COLOR_YELLOW "  [2] Change difficulty       " COLOR_RESET COLOR_CYAN "│\n" COLOR_RESET);
                    printf(COLOR_CYAN "  │" COLOR_RED   "  [3] Back to main menu       " COLOR_RESET COLOR_CYAN "│\n" COLOR_RESET);
                    printf(COLOR_CYAN "  └──────────────────────────────┘\n" COLOR_RESET);
                    printf(COLOR_BOLD "  Choice: " COLOR_RESET);

                    int rep = get_int_input(1, 3);
                    if      (rep == 1) { /* replay same difficulty — loop */ }
                    else if (rep == 2) { select_difficulty(&player); }
                    else               { replay = 0; }
                }
                break;
            }

            /* ── Full leaderboard ── */
            case 2:
                display_leaderboard();
                break;

            /* ── Leaderboard filtered by difficulty ── */
            case 3: {
                clear_screen();
                printf(COLOR_BOLD "\n  Filter leaderboard by difficulty:\n");
                printf("  [1] Easy  [2] Normal  [3] Hard\n\n  Choice: " COLOR_RESET);
                int d = get_int_input(1, 3) - 1;
                display_leaderboard_filtered(d);
                break;
            }

            /* ── Admin panel ── */
            case 4:
                admin_menu();
                break;

            /* ── Quit ── */
            case 5:
                display_goodbye();
                running = 0;
                break;
        }
    }

    return 0;
}
