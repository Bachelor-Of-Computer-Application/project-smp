/* ============================================================
   leaderboard.c — Save / load / sort / display high scores
   Scores stored as binary ScoreEntry structs in scores.dat
   ============================================================ */

#include "leaderboard.h"
#include "ui.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ── Save a player's result to the scores file ── */
void save_score(Player *p) {
    system("mkdir -p data 2>/dev/null || mkdir data 2>nul");

    ScoreEntry entry;
    memset(&entry, 0, sizeof(entry));
    strncpy(entry.name,  p->name,  MAX_NAME_LEN - 1);
    entry.score      = p->score;
    entry.difficulty = p->difficulty;
    entry.correct    = p->correct_answers;
    entry.total      = p->questions_answered;
    get_current_date(entry.date, sizeof(entry.date));

    FILE *fp = fopen(SCORES_FILE, "ab");
    if (!fp) {
        printf(COLOR_RED "  ✗ Could not save score.\n" COLOR_RESET);
        return;
    }
    fwrite(&entry, sizeof(ScoreEntry), 1, fp);
    fclose(fp);
    printf(COLOR_GREEN "  ✔ Score saved to leaderboard!\n" COLOR_RESET);
}

/* ── Load all score entries from the file ── */
void load_scores(ScoreEntry *entries, int *count) {
    *count = 0;
    FILE *fp = fopen(SCORES_FILE, "rb");
    if (!fp) return;

    while (*count < MAX_SCORES &&
           fread(&entries[*count], sizeof(ScoreEntry), 1, fp) == 1) {
        (*count)++;
    }
    fclose(fp);
}

/* ── Sort scores descending by score (bubble sort — simple & readable) ── */
void sort_scores(ScoreEntry *entries, int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (entries[j].score < entries[j + 1].score) {
                ScoreEntry tmp   = entries[j];
                entries[j]       = entries[j + 1];
                entries[j + 1]   = tmp;
            }
        }
    }
}

/* ── Render one row of the leaderboard table ── */
static void print_score_row(int rank, ScoreEntry *e) {
    const char *medals[]    = { "🥇", "🥈", "🥉", "  ", "  " };
    const char *diff_str[]  = { "Easy  ", "Normal", "Hard  " };
    const char *diff_col[]  = { COLOR_GREEN, COLOR_YELLOW, COLOR_RED };
    const char *medal = (rank <= 3) ? medals[rank - 1] : "  ";

    printf(COLOR_CYAN "  ║ " COLOR_RESET);
    printf("%s " COLOR_BOLD "%3d " COLOR_RESET, medal, rank);
    printf(COLOR_WHITE "%-20s" COLOR_RESET, e->name);
    printf(COLOR_YELLOW "%6d  " COLOR_RESET, e->score);
    printf(COLOR_GREEN "%3d/%-3d  " COLOR_RESET, e->correct, e->total);
    printf("%s%-8s" COLOR_RESET, diff_col[e->difficulty], diff_str[e->difficulty]);
    printf(COLOR_WHITE "  %s" COLOR_RESET, e->date);
    printf(COLOR_CYAN "  ║\n" COLOR_RESET);
}

/* ── Display the full leaderboard (all difficulties) ── */
void display_leaderboard(void) {
    ScoreEntry entries[MAX_SCORES];
    int count = 0;
    load_scores(entries, &count);

    display_leaderboard_header();

    if (count == 0) {
        printf(COLOR_CYAN "  ║" COLOR_WHITE
               "          No scores yet. Be the first to play!          "
               COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    } else {
        sort_scores(entries, count);
        int show = (count < 10) ? count : 10;   /* Top 10 */
        for (int i = 0; i < show; i++) {
            print_score_row(i + 1, &entries[i]);
        }
    }

    printf(COLOR_CYAN "  ╚══════════════════════════════════════════════════════════════╝\n" COLOR_RESET);
    pause_enter();
}

/* ── Display leaderboard filtered to one difficulty level ── */
void display_leaderboard_filtered(int difficulty) {
    ScoreEntry all[MAX_SCORES];
    ScoreEntry filtered[MAX_SCORES];
    int total = 0, fcount = 0;

    load_scores(all, &total);
    for (int i = 0; i < total; i++) {
        if (all[i].difficulty == difficulty && fcount < MAX_SCORES) {
            filtered[fcount++] = all[i];
        }
    }

    const char *diff_label[] = { "EASY", "NORMAL", "HARD" };
    display_leaderboard_header();
    printf(COLOR_CYAN "  ║" COLOR_BOLD COLOR_WHITE
           "                 Filtered: %-8s                         "
           COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET, diff_label[difficulty]);
    printf(COLOR_CYAN "  ╠══════════════════════════════════════════════════════════════╣\n" COLOR_RESET);

    if (fcount == 0) {
        printf(COLOR_CYAN "  ║" COLOR_WHITE
               "         No scores for this difficulty yet.               "
               COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    } else {
        sort_scores(filtered, fcount);
        int show = (fcount < 10) ? fcount : 10;
        for (int i = 0; i < show; i++) {
            print_score_row(i + 1, &filtered[i]);
        }
    }

    printf(COLOR_CYAN "  ╚══════════════════════════════════════════════════════════════╝\n" COLOR_RESET);
    pause_enter();
}
