/* ============================================================
   ui.c — ASCII art banners, menus, and visual feedback
   ============================================================ */

#include "ui.h"
#include <stdio.h>

/* ── Main title banner ── */
void display_main_banner(void) {
    clear_screen();
    printf("\n");
    printf(COLOR_CYAN "  ╔══════════════════════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_YELLOW COLOR_BOLD
           "          ████████╗██████╗ ██╗   ██╗██╗ █████╗           " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_YELLOW COLOR_BOLD
           "          ╚══██╔══╝██╔══██╗██║   ██║██║██╔══██╗          " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_YELLOW COLOR_BOLD
           "             ██║   ██████╔╝██║   ██║██║███████║          " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_YELLOW COLOR_BOLD
           "             ██║   ██╔══██╗██║   ██║██║██╔══██║          " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_YELLOW COLOR_BOLD
           "             ██║   ██║  ██║╚██████╔╝██║██║  ██║          " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_YELLOW COLOR_BOLD
           "             ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝╚═╝  ╚═╝          " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_MAGENTA
           "                 ★  Q U I Z  G A M E  ★                 " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_RESET COLOR_WHITE
           "              Test your knowledge. Beat the clock!        " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ╚══════════════════════════════════════════════════════╝\n" COLOR_RESET);
    printf("\n");
}

/* ── Main menu options ── */
void display_main_menu(void) {
    printf(COLOR_WHITE "  ┌──────────────────────────────────────┐\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_BOLD "            MAIN  MENU                " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  ├──────────────────────────────────────┤\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_GREEN "  [1]  🎮  Play Quiz                  " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_CYAN "  [2]  🏆  Leaderboard                " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_MAGENTA "  [3]  🎲  Leaderboard by Difficulty  " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_YELLOW "  [4]  🔧  Admin Mode                 " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_RED "  [5]  ❌  Quit                       " COLOR_RESET COLOR_WHITE "│\n" COLOR_RESET);
    printf(COLOR_WHITE "  └──────────────────────────────────────┘\n" COLOR_RESET);
    printf(COLOR_BOLD "\n  Your choice: " COLOR_RESET);
}

/* ── Difficulty selection menu ── */
void display_difficulty_menu(void) {
    printf("\n");
    printf(COLOR_WHITE "  ┌──────────────────────────────────────────┐\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_BOLD "         SELECT  DIFFICULTY              " COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET);
    printf(COLOR_WHITE "  ├──────────────────────────────────────────┤\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_GREEN "  [1]  🟢  EASY    — 10pts | 20s timer  " COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_YELLOW "  [2]  🟡  NORMAL  — 20pts | 15s timer  " COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET);
    printf(COLOR_WHITE "  │" COLOR_RED "  [3]  🔴  HARD    — 30pts | 10s timer  " COLOR_RESET COLOR_WHITE " │\n" COLOR_RESET);
    printf(COLOR_WHITE "  └──────────────────────────────────────────┘\n" COLOR_RESET);
    printf(COLOR_BOLD "\n  Your choice: " COLOR_RESET);
}

/* ── Game over results banner ── */
void display_game_over_banner(int score, int correct, int total) {
    float pct = (total > 0) ? (float)correct / total * 100.0f : 0.0f;

    printf("\n");
    printf(COLOR_YELLOW "  ╔══════════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_YELLOW "  ║" COLOR_BOLD "             GAME  OVER  !               " COLOR_RESET COLOR_YELLOW "║\n" COLOR_RESET);
    printf(COLOR_YELLOW "  ╠══════════════════════════════════════════╣\n" COLOR_RESET);
    printf(COLOR_YELLOW "  ║" COLOR_WHITE "  Final Score  : " COLOR_GREEN COLOR_BOLD "%-6d" COLOR_RESET COLOR_WHITE "                    " COLOR_YELLOW "║\n" COLOR_RESET, score);
    printf(COLOR_YELLOW "  ║" COLOR_WHITE "  Correct      : " COLOR_GREEN "%-2d" COLOR_WHITE " / %-2d                    " COLOR_YELLOW "║\n" COLOR_RESET, correct, total);
    printf(COLOR_YELLOW "  ║" COLOR_WHITE "  Accuracy     : " COLOR_CYAN "%-5.1f%%                       " COLOR_RESET COLOR_YELLOW "║\n" COLOR_RESET, pct);

    /* Grade evaluation */
    printf(COLOR_YELLOW "  ║" COLOR_WHITE "  Grade        : ");
    if      (pct >= 90) printf(COLOR_GREEN  COLOR_BOLD "★ GENIUS ★            " COLOR_RESET);
    else if (pct >= 75) printf(COLOR_GREEN  "✔ EXCELLENT           " COLOR_RESET);
    else if (pct >= 60) printf(COLOR_YELLOW "✔ GOOD                " COLOR_RESET);
    else if (pct >= 40) printf(COLOR_CYAN   "◉ AVERAGE             " COLOR_RESET);
    else                printf(COLOR_RED    "✗ NEEDS PRACTICE      " COLOR_RESET);
    printf(COLOR_YELLOW "║\n" COLOR_RESET);

    printf(COLOR_YELLOW "  ╚══════════════════════════════════════════╝\n" COLOR_RESET);
}

/* ── Correct answer feedback ── */
void display_correct_answer(void) {
    printf("\n  " BG_GREEN COLOR_WHITE COLOR_BOLD
           "  ✔  CORRECT! Well done!  "
           COLOR_RESET "\n");
}

/* ── Wrong answer feedback ── */
void display_wrong_answer(const char *correct_opt) {
    printf("\n  " BG_RED COLOR_WHITE COLOR_BOLD
           "  ✗  WRONG!  "
           COLOR_RESET
           COLOR_RED "  Correct answer was: " COLOR_BOLD "%s" COLOR_RESET "\n",
           correct_opt);
}

/* ── Timeout message ── */
void display_timeout_message(void) {
    printf("\n  " BG_RED COLOR_WHITE COLOR_BOLD
           "  ⏰  TIME'S UP!  "
           COLOR_RESET COLOR_RED "  No answer recorded.\n" COLOR_RESET);
}

/* ── Admin panel banner ── */
void display_admin_banner(void) {
    clear_screen();
    printf("\n");
    printf(COLOR_MAGENTA "  ╔══════════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  ║" COLOR_BOLD COLOR_WHITE "           🔧 ADMIN PANEL 🔧               " COLOR_RESET COLOR_MAGENTA "║\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  ╚══════════════════════════════════════════╝\n" COLOR_RESET);
    printf("\n");
    printf(COLOR_MAGENTA "  ┌──────────────────────────────────────────┐\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  │" COLOR_WHITE "  [1]  ➕  Add New Question               " COLOR_RESET COLOR_MAGENTA "│\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  │" COLOR_WHITE "  [2]  📋  View All Questions             " COLOR_RESET COLOR_MAGENTA "│\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  │" COLOR_WHITE "  [3]  🔍  View Questions by Difficulty   " COLOR_RESET COLOR_MAGENTA "│\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  │" COLOR_WHITE "  [4]  🗑  Delete a Question              " COLOR_RESET COLOR_MAGENTA "│\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  │" COLOR_RED   "  [5]  🔙  Back to Main Menu             " COLOR_RESET COLOR_MAGENTA "│\n" COLOR_RESET);
    printf(COLOR_MAGENTA "  └──────────────────────────────────────────┘\n" COLOR_RESET);
    printf(COLOR_BOLD "\n  Your choice: " COLOR_RESET);
}

/* ── Leaderboard header ── */
void display_leaderboard_header(void) {
    clear_screen();
    printf("\n");
    printf(COLOR_CYAN "  ╔══════════════════════════════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_YELLOW COLOR_BOLD
           "                    🏆  LEADERBOARD  🏆                        "
           COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ╠══════════════════════════════════════════════════════════════╣\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║ " COLOR_BOLD
           "  Rank  Name                Score   Correct  Difficulty  Date  "
           COLOR_RESET COLOR_CYAN " ║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ╠══════════════════════════════════════════════════════════════╣\n" COLOR_RESET);
}

/* ── Progress bar for question number ── */
void display_progress_bar(int current, int total) {
    int bar_width = 30;
    int filled    = (total > 0) ? (current * bar_width / total) : 0;

    printf(COLOR_BOLD "  Progress [" COLOR_RESET);
    printf(COLOR_GREEN);
    for (int i = 0; i < filled; i++)    printf("\xe2\x96\x88");   /* █ */
    printf(COLOR_RESET);
    for (int i = filled; i < bar_width; i++) printf("\xe2\x96\x91"); /* ░ */
    printf(COLOR_BOLD "] " COLOR_RESET);
    printf(COLOR_YELLOW "%d/%d\n" COLOR_RESET, current, total);
}

/* ── Animated loading text ── */
void display_loading(const char *msg) {
    printf("\n  %s", msg);
    fflush(stdout);
    for (int i = 0; i < 3; i++) {
        sleep_ms(300);
        printf(".");
        fflush(stdout);
    }
    printf("\n");
    sleep_ms(200);
}

/* ── Score badge after game ends ── */
void display_score_badge(int score, int difficulty) {
    const char *diff_str[] = { "EASY", "NORMAL", "HARD" };
    const char *diff_col[] = { COLOR_GREEN, COLOR_YELLOW, COLOR_RED };
    printf("\n");
    printf(COLOR_CYAN "  ┌─────────────────────────────┐\n" COLOR_RESET);
    printf(COLOR_CYAN "  │" COLOR_BOLD " 🏅 Score : " COLOR_YELLOW "%-6d" COLOR_RESET
           COLOR_CYAN "              │\n" COLOR_RESET, score);
    printf(COLOR_CYAN "  │" COLOR_BOLD " 🎯 Mode  : %s%-10s" COLOR_RESET
           COLOR_CYAN "         │\n" COLOR_RESET, diff_col[difficulty], diff_str[difficulty]);
    printf(COLOR_CYAN "  └─────────────────────────────┘\n" COLOR_RESET);
}

/* ── Goodbye message ── */
void display_goodbye(void) {
    clear_screen();
    printf("\n\n");
    printf(COLOR_CYAN "  ╔══════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_YELLOW COLOR_BOLD
           "    Thanks for playing TRIVIA QUIZ!   " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║" COLOR_WHITE
           "        See you next time! 👋          " COLOR_RESET COLOR_CYAN "║\n" COLOR_RESET);
    printf(COLOR_CYAN "  ╚══════════════════════════════════════╝\n" COLOR_RESET);
    printf("\n\n");
}

/* ── Animated dots ── */
void animated_dots(const char *msg, int count) {
    printf("  %s", msg);
    fflush(stdout);
    for (int i = 0; i < count; i++) {
        sleep_ms(250);
        printf(" .");
        fflush(stdout);
    }
    printf("\n");
}
