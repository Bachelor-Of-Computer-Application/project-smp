/* ============================================================
   quiz.c — Core quiz engine
   Loads questions, shuffles them, runs the timed game loop,
   calculates scores, and shows results.
   ============================================================ */

#include "quiz.h"
#include "admin.h"
#include "ui.h"
#include "timer.h"
#include "leaderboard.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ── Set per-game config based on difficulty ── */
void configure_session(QuizSession *session, int difficulty) {
    switch (difficulty) {
        case EASY:
            session->q_per_game  = 10;
            session->time_limit  = 20;
            break;
        case NORMAL:
            session->q_per_game  = 10;
            session->time_limit  = 15;
            break;
        case HARD:
            session->q_per_game  = 10;
            session->time_limit  = 10;
            break;
        default:
            session->q_per_game  = 10;
            session->time_limit  = 20;
    }
}

/* ── Load questions matching difficulty from binary file ── */
int load_questions(QuizSession *session, int difficulty) {
    FILE *fp = fopen(QUESTIONS_FILE, "rb");
    if (!fp) {
        printf(COLOR_RED "\n  ✗ No question bank found.\n"
               "    Please add questions via Admin Mode first.\n" COLOR_RESET);
        sleep_ms(1500);
        return 0;
    }

    session->count = 0;
    Question q;

    while (fread(&q, sizeof(Question), 1, fp) == 1) {
        if (q.difficulty == difficulty && session->count < MAX_QUESTIONS) {
            session->questions[session->count++] = q;
        }
    }
    fclose(fp);

    if (session->count == 0) {
        printf(COLOR_RED "\n  ✗ No questions available for this difficulty.\n"
               "    Add some via Admin Mode!\n" COLOR_RESET);
        sleep_ms(1500);
        return 0;
    }

    /* Initialize order array 0, 1, 2, ... count-1 */
    for (int i = 0; i < session->count; i++) session->order[i] = i;
    return 1;
}

/* ── Fisher-Yates shuffle on the order array ── */
void shuffle_questions(QuizSession *session) {
    for (int i = session->count - 1; i > 0; i--) {
        int j = random_range(0, i);
        int tmp            = session->order[i];
        session->order[i]  = session->order[j];
        session->order[j]  = tmp;
    }
}

/* ── Calculate score for one correct answer with timer bonus ── */
int calculate_score(int difficulty, int time_taken) {
    int base  = 0;
    int bonus = 0;
    int bonus_threshold = 0;

    switch (difficulty) {
        case EASY:
            base = BASE_SCORE_EASY;   bonus = BONUS_EASY;
            bonus_threshold = BONUS_TIME_EASY;   break;
        case NORMAL:
            base = BASE_SCORE_NORMAL; bonus = BONUS_NORMAL;
            bonus_threshold = BONUS_TIME_NORMAL; break;
        case HARD:
            base = BASE_SCORE_HARD;   bonus = BONUS_HARD;
            bonus_threshold = BONUS_TIME_HARD;   break;
    }
    return (time_taken <= bonus_threshold) ? base + bonus : base;
}

/* ── Display one question with options and timer bar ── */
void display_question(QuizSession *session, int idx, int q_num, int total) {
    Question *q = &session->questions[session->order[idx]];

    clear_screen();
    printf("\n");

    /* Header row */
    printf(COLOR_CYAN "  ╔══════════════════════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_CYAN "  ║ " COLOR_BOLD COLOR_WHITE "Question %2d / %-2d" COLOR_RESET
           COLOR_CYAN "                                    ║\n" COLOR_RESET, q_num, total);
    printf(COLOR_CYAN "  ╚══════════════════════════════════════════════════════╝\n" COLOR_RESET);

    /* Progress bar */
    display_progress_bar(q_num - 1, total);
    printf("\n");

    /* Question text */
    printf(COLOR_WHITE COLOR_BOLD "  ❓ %s\n\n" COLOR_RESET, q->question);

    /* Answer options */
    const char *opt_labels[] = {"A", "B", "C", "D"};
    const char *opt_colors[] = {COLOR_CYAN, COLOR_MAGENTA, COLOR_YELLOW, COLOR_BLUE};
    for (int i = 0; i < 4; i++) {
        printf("  %s[%s]%s %s\n",
               opt_colors[i], opt_labels[i], COLOR_RESET,
               q->options[i]);
    }
    printf("\n");
}

/* ── Return 1 if user's answer index matches correct answer ── */
int check_answer(QuizSession *session, int idx, int answer) {
    return (session->questions[session->order[idx]].correct == answer);
}

/* ── Show the end-of-game summary ── */
void show_result_screen(Player *player) {
    clear_screen();
    display_game_over_banner(player->score, player->correct_answers,
                             player->questions_answered);
    display_player_stats(player);
    display_score_badge(player->score, player->difficulty);
}

/* ── Main quiz game loop ── */
void run_quiz(Player *player) {
    QuizSession session;
    memset(&session, 0, sizeof(session));

    /* Configure session parameters for chosen difficulty */
    configure_session(&session, player->difficulty);

    /* Load and shuffle questions */
    display_loading("  Loading questions");
    if (!load_questions(&session, player->difficulty)) return;
    shuffle_questions(&session);

    /* Cap to available questions */
    int total_q = (session.count < session.q_per_game)
                ? session.count
                : session.q_per_game;

    Timer   timer;
    char    input_buf[8];
    int     answer_idx;

    /* ─── Question loop ─── */
    for (int i = 0; i < total_q; i++) {
        display_question(&session, i, i + 1, total_q);

        /* Start countdown */
        timer_start(&timer, session.time_limit);
        display_timer_bar(session.time_limit, session.time_limit);

        /* Prompt for answer */
        printf(COLOR_BOLD "  Your answer (1=A, 2=B, 3=C, 4=D): " COLOR_RESET);
        fflush(stdout);

        /*
         * Non-blocking input: We check for timeout while waiting.
         * On most POSIX systems we rely on select(); on Windows we
         * use a simple polling approach via kbhit().  For maximum
         * portability we use a simple timed fgets loop here.
         *
         * Approach: read with a short-enough deadline so we can
         * re-print the timer each second.  We redraw the question
         * once per second until input arrives or time runs out.
         */

        int answered    = 0;
        int time_taken  = 0;

        while (!timer_expired(&timer)) {
            /* Re-display timer bar each second */
            int remaining = timer_remaining(&timer);

            /* Use stdin with select for non-blocking on POSIX */
            /* Fallback: just read and check elapsed */

            /* For portability we do a blocking read but check elapsed
               before and after; on most systems fgets returns quickly */
            printf("\r  ⏱  Timer [");
            {
                int bar_width = 20;
                int filled = (session.time_limit > 0)
                           ? (remaining * bar_width / session.time_limit) : 0;
                const char *bc = (remaining > session.time_limit / 2) ? COLOR_GREEN
                               : (remaining > session.time_limit / 4) ? COLOR_YELLOW
                                                                       : COLOR_RED;
                printf("%s", bc);
                for (int b = 0; b < filled; b++) putchar('#');
                printf(COLOR_RESET);
                for (int b = filled; b < bar_width; b++) putchar('-');
            }
            printf("] %2ds  Answer: ", remaining);
            fflush(stdout);

            /* Give the user 1 second to type before re-checking */
            sleep_ms(1000);

            if (timer_expired(&timer)) break;

            /* Check if user has typed something — we'll read at end */
        }

        /*
         * Because blocking fgets makes a portable timer very complex
         * without threads, we use a pragmatic approach:
         * Print the question, show a static timer, then read input.
         * After reading, compute time_taken.  If over limit → timeout.
         */

        /* Redraw question cleanly for input */
        display_question(&session, i, i + 1, total_q);
        display_timer_bar(timer_remaining(&timer) > 0 ? timer_remaining(&timer) : 0,
                          session.time_limit);

        timer_start(&timer, session.time_limit);  /* restart for clean read */
        printf(COLOR_BOLD "  Your answer (1=A, 2=B, 3=C, 4=D, 0=Skip): " COLOR_RESET);
        fflush(stdout);

        if (fgets(input_buf, sizeof(input_buf), stdin) == NULL) {
            input_buf[0] = '0';
        }
        input_buf[strcspn(input_buf, "\n")] = '\0';

        time_taken = timer_elapsed(&timer);

        /* Validate input */
        int choice = atoi(input_buf);

        /* Check timeout */
        if (time_taken >= session.time_limit) {
            display_timeout_message();
            player->questions_answered++;
            sleep_ms(1200);
            continue;
        }

        if (choice < 1 || choice > 4) {
            /* Skip / invalid */
            printf(COLOR_YELLOW "  Skipped.\n" COLOR_RESET);
            player->questions_answered++;
            sleep_ms(800);
            continue;
        }

        answer_idx = choice - 1;
        answered   = 1;
        player->questions_answered++;

        /* ── Evaluate answer ── */
        if (answered && check_answer(&session, i, answer_idx)) {
            int pts = calculate_score(player->difficulty, time_taken);
            player->score += pts;
            player->correct_answers++;
            display_correct_answer();
            printf(COLOR_GREEN "  +" COLOR_BOLD "%d pts" COLOR_RESET
                   COLOR_GREEN " (answered in %ds)\n" COLOR_RESET, pts, time_taken);
        } else if (answered) {
            Question *qp = &session.questions[session.order[i]];
            char correct_text[MAX_OPTION_LEN + 4];
            snprintf(correct_text, sizeof(correct_text), "%s",
                     qp->options[qp->correct]);
            display_wrong_answer(correct_text);
        }

        player->total_time += time_taken;
        sleep_ms(1400);
    }

    /* ─── End of quiz ─── */
    show_result_screen(player);
    save_score(player);
    pause_enter();
}
