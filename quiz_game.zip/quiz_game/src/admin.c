/* ============================================================
   admin.c — Admin panel: add, view, and delete questions
   Question data stored as binary structs in questions.dat
   ============================================================ */

#include "admin.h"
#include "ui.h"
#include "quiz.h"
#include <stdio.h>
#include <string.h>

/* ── Verify admin password (hidden input not portable; prompt clearly) ── */
int admin_login(void) {
    char input[32];
    clear_screen();
    printf("\n");
    printf(COLOR_YELLOW "  ╔══════════════════════════════════════╗\n" COLOR_RESET);
    printf(COLOR_YELLOW "  ║" COLOR_BOLD "        🔒 ADMIN LOGIN REQUIRED        " COLOR_RESET COLOR_YELLOW "║\n" COLOR_RESET);
    printf(COLOR_YELLOW "  ╚══════════════════════════════════════╝\n" COLOR_RESET);
    printf(COLOR_BOLD "\n  Password: " COLOR_RESET);
    get_string_input(input, sizeof(input));

    if (strcmp(input, ADMIN_PASSWORD) == 0) {
        printf(COLOR_GREEN "\n  ✔ Access granted!\n" COLOR_RESET);
        sleep_ms(700);
        return 1;
    }
    printf(COLOR_RED "\n  ✗ Wrong password. Access denied.\n" COLOR_RESET);
    sleep_ms(1000);
    return 0;
}

/* ── Total number of questions currently saved ── */
int get_total_questions(void) {
    FILE *fp = fopen(QUESTIONS_FILE, "rb");
    if (!fp) return 0;

    fseek(fp, 0, SEEK_END);
    long size  = ftell(fp);
    fclose(fp);
    return (int)(size / sizeof(Question));
}

/* ── Append one question struct to the binary file ── */
int save_question(Question *q) {
    /* Ensure data/ directory exists (best-effort; won't work on MSVC) */
    system("mkdir -p data 2>/dev/null || mkdir data 2>nul");

    FILE *fp = fopen(QUESTIONS_FILE, "ab");
    if (!fp) {
        printf(COLOR_RED "  ✗ Could not open questions file for writing.\n" COLOR_RESET);
        return 0;
    }
    fwrite(q, sizeof(Question), 1, fp);
    fclose(fp);
    return 1;
}

/* ── Interactive form to add a new question ── */
void admin_add_question(void) {
    Question q;
    memset(&q, 0, sizeof(q));

    clear_screen();
    printf(COLOR_MAGENTA "\n  ─── ADD NEW QUESTION ───\n\n" COLOR_RESET);

    /* Question text */
    printf(COLOR_BOLD "  Question text:\n  > " COLOR_RESET);
    get_string_input(q.question, MAX_QUESTION_LEN);
    if (strlen(q.question) == 0) {
        printf(COLOR_RED "  Question cannot be empty.\n" COLOR_RESET);
        pause_enter(); return;
    }

    /* Four options */
    const char *labels[] = {"A", "B", "C", "D"};
    for (int i = 0; i < 4; i++) {
        printf(COLOR_BOLD "  Option %s:\n  > " COLOR_RESET, labels[i]);
        get_string_input(q.options[i], MAX_OPTION_LEN);
    }

    /* Correct answer */
    printf(COLOR_BOLD "\n  Correct answer (1=A, 2=B, 3=C, 4=D): " COLOR_RESET);
    q.correct = get_int_input(1, 4) - 1;

    /* Difficulty */
    printf(COLOR_BOLD "  Difficulty (1=Easy, 2=Normal, 3=Hard): " COLOR_RESET);
    q.difficulty = get_int_input(1, 3) - 1;

    /* Confirm and save */
    printf(COLOR_YELLOW "\n  Saving question...\n" COLOR_RESET);
    if (save_question(&q)) {
        printf(COLOR_GREEN "  ✔ Question saved successfully! (Total: %d)\n" COLOR_RESET,
               get_total_questions());
    }
    pause_enter();
}

/* ── Display all questions stored in the file ── */
void admin_view_questions(void) {
    FILE *fp = fopen(QUESTIONS_FILE, "rb");
    if (!fp) {
        printf(COLOR_RED "\n  No questions found. Add some first!\n" COLOR_RESET);
        pause_enter(); return;
    }

    clear_screen();
    const char *diff_label[] = { "EASY", "NORMAL", "HARD" };
    const char *diff_col[]   = { COLOR_GREEN, COLOR_YELLOW, COLOR_RED };
    const char *opt_labels[] = {"A", "B", "C", "D"};

    Question q;
    int idx = 1;
    printf(COLOR_CYAN "\n  ─── ALL QUESTIONS (%d total) ───\n\n" COLOR_RESET,
           get_total_questions());

    while (fread(&q, sizeof(Question), 1, fp) == 1) {
        printf(COLOR_BOLD "  [%d] " COLOR_RESET COLOR_WHITE "%s\n" COLOR_RESET, idx, q.question);
        for (int i = 0; i < 4; i++) {
            if (i == q.correct)
                printf(COLOR_GREEN "      %s) %s ✔\n" COLOR_RESET, opt_labels[i], q.options[i]);
            else
                printf("      %s) %s\n", opt_labels[i], q.options[i]);
        }
        printf("  Difficulty: %s%s%s\n\n",
               diff_col[q.difficulty], diff_label[q.difficulty], COLOR_RESET);
        idx++;
    }
    fclose(fp);
    pause_enter();
}

/* ── View questions filtered by difficulty ── */
void admin_view_by_difficulty(int difficulty) {
    FILE *fp = fopen(QUESTIONS_FILE, "rb");
    if (!fp) {
        printf(COLOR_RED "\n  No questions file found.\n" COLOR_RESET);
        pause_enter(); return;
    }

    const char *diff_label[] = { "EASY", "NORMAL", "HARD" };
    const char *opt_labels[] = { "A", "B", "C", "D" };
    Question q;
    int idx = 1;

    clear_screen();
    printf(COLOR_CYAN "\n  ─── %s QUESTIONS ───\n\n" COLOR_RESET, diff_label[difficulty]);

    while (fread(&q, sizeof(Question), 1, fp) == 1) {
        if (q.difficulty != difficulty) continue;
        printf(COLOR_BOLD "  [%d] " COLOR_WHITE "%s\n" COLOR_RESET, idx, q.question);
        for (int i = 0; i < 4; i++) {
            if (i == q.correct)
                printf(COLOR_GREEN "      %s) %s ✔\n" COLOR_RESET, opt_labels[i], q.options[i]);
            else
                printf("      %s) %s\n", opt_labels[i], q.options[i]);
        }
        printf("\n");
        idx++;
    }
    if (idx == 1) printf(COLOR_YELLOW "  No questions found for this difficulty.\n" COLOR_RESET);
    fclose(fp);
    pause_enter();
}

/* ── Delete a question by its sequential number ── */
void admin_delete_question(void) {
    int total = get_total_questions();
    if (total == 0) {
        printf(COLOR_RED "\n  No questions to delete.\n" COLOR_RESET);
        pause_enter(); return;
    }

    admin_view_questions();   /* Show numbered list first */

    printf(COLOR_BOLD "  Enter question number to delete (1-%d): " COLOR_RESET, total);
    int del_idx = get_int_input(1, total) - 1;   /* 0-based */

    /* Load all questions into memory */
    Question *bank = (Question *)malloc(total * sizeof(Question));
    if (!bank) { printf(COLOR_RED "  Memory error.\n" COLOR_RESET); return; }

    FILE *fp = fopen(QUESTIONS_FILE, "rb");
    if (!fp) { free(bank); return; }
    fread(bank, sizeof(Question), total, fp);
    fclose(fp);

    /* Rewrite file without the deleted entry */
    fp = fopen(QUESTIONS_FILE, "wb");
    if (!fp) { free(bank); return; }
    for (int i = 0; i < total; i++) {
        if (i != del_idx) fwrite(&bank[i], sizeof(Question), 1, fp);
    }
    fclose(fp);
    free(bank);

    printf(COLOR_GREEN "\n  ✔ Question #%d deleted. Remaining: %d\n" COLOR_RESET,
           del_idx + 1, get_total_questions());
    pause_enter();
}

/* ── Admin panel main menu loop ── */
void admin_menu(void) {
    if (!admin_login()) return;

    int choice;
    do {
        display_admin_banner();
        choice = get_int_input(1, 5);
        switch (choice) {
            case 1: admin_add_question(); break;
            case 2: admin_view_questions(); break;
            case 3:
                clear_screen();
                printf(COLOR_BOLD "\n  Select difficulty to view (1=Easy, 2=Normal, 3=Hard): " COLOR_RESET);
                int d = get_int_input(1, 3) - 1;
                admin_view_by_difficulty(d);
                break;
            case 4: admin_delete_question(); break;
            case 5: printf(COLOR_GREEN "\n  Returning to main menu...\n" COLOR_RESET); sleep_ms(500); break;
        }
    } while (choice != 5);
}
