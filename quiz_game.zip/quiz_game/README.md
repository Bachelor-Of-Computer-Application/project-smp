# 🎮 Terminal Quiz Game — C Project

A complete, terminal-based Quiz Game written in C with:
- Multiple choice questions
- 3 difficulty levels (Easy / Normal / Hard)
- Countdown timer per question
- Score & leaderboard system (saved to binary files)
- Randomized question order
- Replay option
- Admin panel to add/delete questions
- Colorful ASCII terminal UI

---

## 📁 Project Structure

```
quiz_game/
├── src/
│   ├── main.c          ← Entry point, main menu
│   ├── quiz.c          ← Core game loop, scoring
│   ├── player.c        ← Player struct, name, difficulty
│   ├── leaderboard.c   ← Save/load/sort/display scores
│   ├── admin.c         ← Admin CRUD on questions
│   ├── timer.c         ← Countdown timer
│   ├── ui.c            ← ASCII banners, menus, colors
│   └── utils.c         ← Input helpers, RNG, sleep
├── include/
│   ├── quiz.h
│   ├── player.h
│   ├── leaderboard.h
│   ├── admin.h
│   ├── timer.h
│   ├── ui.h
│   └── utils.h
├── data/
│   ├── questions.dat   ← Binary question bank (auto-created)
│   └── scores.dat      ← Binary leaderboard (auto-created)
├── seed_questions.c    ← One-time question seeder
├── Makefile
└── README.md
```

---

## 🔧 How to Compile & Run

### Step 1 — Compile the game

```bash
make
# OR manually:
gcc -Wall -Wextra -std=c99 -I include -o quiz src/*.c
```

### Step 2 — Seed the question bank (first time only)

```bash
gcc -o seed seed_questions.c
./seed
```

This creates `data/questions.dat` with 45 pre-written questions
(15 Easy, 15 Normal, 15 Hard).

### Step 3 — Run the game

```bash
./quiz
# OR:
make run
```

---

## 🪟 Windows (MinGW / MSYS2)

```bash
gcc -Wall -std=c99 -I include -o quiz.exe src/*.c
gcc -o seed.exe seed_questions.c
seed.exe
quiz.exe
```

---

## 🔑 Admin Mode

- From the main menu select **[4] Admin Mode**
- Default password: `admin123`
- You can add, view, and delete questions

---

## 🎯 Scoring System

| Difficulty | Base Points | Bonus (if fast) | Time Limit |
|------------|-------------|-----------------|------------|
| Easy       | 10 pts      | +5 pts (≤10s)   | 20s        |
| Normal     | 20 pts      | +10 pts (≤15s)  | 15s        |
| Hard       | 30 pts      | +15 pts (≤20s)  | 10s        |

---

## ❗ Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `No question bank found` | Run `./seed` first |
| `Permission denied` | Run `chmod +x quiz` |
| Colors look broken | Use a terminal that supports ANSI (Linux/macOS Terminal, Windows Terminal) |
| `mkdir: command not found` | Create `data/` folder manually |
| Garbled characters | Ensure terminal uses UTF-8 encoding |

---

## 🚀 Future Upgrade Ideas

- **Login system** — hash passwords, per-user profiles
- **Categories** — add a `category` field to `Question`
- **Multiplayer** — turn-based with 2 `Player` structs
- **Achievements** — badges stored in a `profile.dat`
- **Hints** — add `hint[128]` field, deduct points to reveal
- **Network mode** — TCP sockets for remote play
- **Stats** — per-category accuracy graphs in terminal
